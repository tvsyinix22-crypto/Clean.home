package com.clean.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var row: LinearLayout
    private lateinit var title: TextView
    private val prefs by lazy { getSharedPreferences("launch_counts", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF0B0F1A.toInt(), 0xFF1B2440.toInt(), 0xFF0A0A10.toInt())
            )
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(64), dp(40), dp(64), dp(40))
        }

        // Top bar: date + time on the right
        val bar = LinearLayout(this).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            setTextColor(0xB3FFFFFF.toInt()); textSize = 18f
            setPadding(0, 0, dp(24), 0)
        }
        val time = TextClock(this).apply {
            format12Hour = "h:mm a"; format24Hour = "HH:mm"
            setTextColor(Color.WHITE); textSize = 28f
        }
        bar.addView(date); bar.addView(time)
        content.addView(bar, LinearLayout.LayoutParams(-1, -2))

        content.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))

        title = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 40f
            setPadding(dp(8), 0, 0, dp(20))
        }
        content.addView(title, LinearLayout.LayoutParams(-1, -2))

        row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            setPadding(dp(8), dp(24), dp(8), dp(24)) // room for focus scale-up
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row, ViewGroup.LayoutParams(-2, -2))
        }
        content.addView(scroller, LinearLayout.LayoutParams(-1, -2))

        content.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1.4f))

        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val focusedIndex = (0 until row.childCount).firstOrNull { row.getChildAt(it).hasFocus() } ?: 0
        populate()
        row.getChildAt(focusedIndex.coerceAtMost(row.childCount - 1))?.requestFocus()
    }

    private fun populate() {
        row.removeAllViews()
        val pm = packageManager
        val tv = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        val std = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val seen = HashSet<String>()
        val apps: List<ResolveInfo> = (tv + std)
            .filter { it.activityInfo.packageName != packageName && seen.add(it.activityInfo.packageName) }
            .sortedWith(compareByDescending<ResolveInfo> { prefs.getInt(it.activityInfo.packageName, 0) }
                .thenBy { it.loadLabel(pm).toString().lowercase() })

        apps.forEach { row.addView(tile(it)) }
        title.text = ""
    }

    private fun tile(info: ResolveInfo): View {
        val pm = packageManager
        val pkg = info.activityInfo.packageName
        val name = info.loadLabel(pm).toString()
        val radius = dp(18).toFloat()

        val card = FrameLayout(this).apply {
            isFocusable = true
            isFocusableInTouchMode = false
            background = GradientDrawable().apply {
                setColor(0xFF23283A.toInt()); cornerRadius = radius
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, radius)
            }
            clipToOutline = true
            elevation = dp(2).toFloat()
        }

        val banner = try { info.activityInfo.loadBanner(pm) } catch (e: Exception) { null }
        if (banner != null) {
            card.addView(ImageView(this).apply {
                setImageDrawable(banner); scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(-1, -1))
        } else {
            card.addView(ImageView(this).apply {
                setImageDrawable(info.loadIcon(pm)); scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
        }

        card.setOnFocusChangeListener { v, focused ->
            v.animate().scaleX(if (focused) 1.14f else 1f).scaleY(if (focused) 1.14f else 1f)
                .translationZ(if (focused) dp(14).toFloat() else 0f).setDuration(140).start()
            if (focused) title.text = name
        }
        card.setOnClickListener {
            val launch = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                prefs.edit().putInt(pkg, prefs.getInt(pkg, 0) + 1).apply()
                startActivity(launch)
            }
        }

        card.layoutParams = LinearLayout.LayoutParams(dp(256), dp(144)).apply { marginEnd = dp(28) }
        return card
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* a launcher never exits */ }
}
