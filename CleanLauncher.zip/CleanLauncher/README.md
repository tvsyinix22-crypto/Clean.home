# Clean Home — ad-free Apple TV-style launcher

- Big rounded tiles, focus pop animation, app name above the row, clock top-right.
- Most-launched apps float to the front automatically.
- No INTERNET permission, no recommendations, no ads, no tracking.

## Build
1. Open this folder in Android Studio (Koala or newer), let Gradle sync.
2. Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk

## Install on the TV (ADB over network)
    adb connect <TV_IP>:5555
    adb install -r app-debug.apk

## Make it the Home screen
Press Home on the remote. If Android asks which launcher to use, pick "Clean Home" > Always.
If it doesn't ask (common on locked-down TVs), find and disable the stock launcher:

    adb shell cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME
    adb shell pm disable-user --user 0 <stock.launcher.package>

Undo anytime: adb shell pm enable <stock.launcher.package>
Keep Clean Home installed first, or the TV will have no Home screen.
